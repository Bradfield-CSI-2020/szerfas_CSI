- See new processes start on connect

- Watch traffic with Wireshark

	psql -h 127.0.0.1 -p 5432 test

- Step through query with a debugger

	- Follow along with one of:
		- https://www.postgresql.org/developer/backend/
		- https://www.postgresql.org/docs/devel/query-path.html
	- Breakpoints:	
		raw_parser
		parse_analyze
		RewriteQuery
		query_planner
		ExecutorRun

- Inspect on-disk files

- Look at query plans

	EXPLAIN ...
	EXPLAIN ANALYZE ...

---

pg_ctl -D pg_data stop
pg_ctl -D pg_data -l logfile start

-- see what processes started
ps -eo pid,command | grep postgres | grep -v grep

-- in new terminal tab
psql test

-- ps again to see new process
ps -eo pid,command | grep postgres | grep -v grep

-- shut down psql
-- start capturing traffic using wireshark

psql -h 127.0.0.1 -p 5432 test
-- make some queries

-- stop capturing traffic using wireshark
-- inspect traffic


## Useful Commands

-- start postgres from shell
-- $ pg_ctl -D pg_data -l logfile start

-- stop postgres from shell
-- $ pg_ctl -D pg_data stop

-- create a new database
-- $ createdb <db name>

-- psql shell
-- $ psql <db name>

-- show tables
\dt

-- create table
create table foo (a int, b varchar(255));

-- insert row
insert into foo(a, b) values (1, 'hello');

-- show on-disk location of table foo
SELECT pg_relation_filepath('foo');

-- flush write-ahead log
CHECKPOINT;

## Tutorials

https://www.postgresqltutorial.com/postgresql-insert/
https://www.postgresqltutorial.com/import-csv-file-into-posgresql-table/
https://www.postgresqltutorial.com/postgresql-foreign-key/

## Further Resources

https://www.postgresqltutorial.com/
https://wiki.postgresql.org/wiki/Developer_FAQ
http://www.interdb.jp/pg/
https://www.postgrescompare.com/2017/06/11/pg_catalog_constraints.html

---


- Look at query plans

	EXPLAIN ...
	EXPLAIN ANALYZE ...

---

pg_ctl -D pg_data stop
pg_ctl -D pg_data -l logfile start

-- see what processes started
ps -eo pid,command | grep postgres | grep -v grep

-- in new terminal tab
psql test

-- ps again to see new process
ps -eo pid,command | grep postgres | grep -v grep

-- shut down psql
-- start capturing traffic using wireshark

psql -h 127.0.0.1 -p 5432 test
-- make some queries

-- stop capturing traffic using wireshark
-- inspect traffic