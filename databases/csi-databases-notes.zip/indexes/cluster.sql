\timing on

-- movies with bulk load
CREATE TABLE movies (id integer, title varchar(255), genres text);
COPY movies(id, title, genres) FROM '/Users/elliott/Desktop/databases/ml-20m/movies.csv' DELIMITER ',' CSV HEADER;
CHECKPOINT;

-- what does the heap data look like?
SELECT pg_relation_filepath('movies');
# pg_filedump -f -i -D int,varchar,text <path> | less
# how are the tuples ordered, and why?

-- add primary key / index
ALTER TABLE movies ADD PRIMARY KEY (id);
CREATE INDEX idx_movies_title ON movies (title);

-- how well do these queries perform?
EXPLAIN ANALYZE SELECT * FROM movies WHERE id > 5000;
EXPLAIN ANALYZE SELECT * FROM movies WHERE id > 5000 and id < 50000;
EXPLAIN ANALYZE SELECT * FROM movies WHERE id > 5000 and id < 6000;

EXPLAIN ANALYZE SELECT * FROM movies WHERE title > 'A';
EXPLAIN ANALYZE SELECT * FROM movies WHERE title > 'A' and title < 'C';
EXPLAIN ANALYZE SELECT * FROM movies WHERE title > 'A' and title < 'Ab';

-- cluster using index on title
CLUSTER movies USING idx_movies_title;

-- what does the heap data look like now?

-- how well do the above queries perform now?

-- if we insert more data, where would it get added?
INSERT INTO movies (id, title, genres) VALUES (200000, 'BEST MOVIE', 'Comedy|Horror');
CHECKPOINT;

-- what are the implications about clustering?