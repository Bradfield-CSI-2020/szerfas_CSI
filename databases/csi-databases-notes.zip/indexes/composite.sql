DROP INDEX idx_movies_title;

CREATE INDEX idx_movies_title_genres ON movies (title, genres);
SELECT pg_relation_filepath('idx_movies_title_genres');

-- What gets indexed?
-- pg_filedump -f -i <path> | less

EXPLAIN SELECT * FROM movies WHERE title > 'A';
EXPLAIN SELECT * FROM movies WHERE title > 'A' AND title < 'C';
EXPLAIN SELECT * FROM movies WHERE title > 'A' AND title < 'Ab';

EXPLAIN SELECT * FROM movies WHERE title > 'A' AND genres > 'A';
EXPLAIN SELECT * FROM movies WHERE title > 'A' AND title < 'C' AND genres > 'A';

EXPLAIN SELECT * FROM movies WHERE genres > 'A' AND title > 'A' AND title < 'Ab';
EXPLAIN SELECT * FROM movies WHERE title > 'A' AND title < 'Ab' AND genres > 'A';

EXPLAIN SELECT * FROM movies WHERE genres > 'A';
EXPLAIN SELECT * FROM movies WHERE genres > 'A' AND genres < 'C';
EXPLAIN SELECT * FROM movies WHERE genres > 'A' AND genres < 'Ab';

EXPLAIN SELECT * FROM movies WHERE title = 'A' AND genres > 'A';
EXPLAIN SELECT * FROM movies WHERE genres = 'A' AND title > 'A';
