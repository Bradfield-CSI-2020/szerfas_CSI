\timing on

-- movies with bulk load
CREATE TABLE movies (id integer, title varchar(255), genres text);
COPY movies(id, title, genres) FROM '/Users/eyj/Downloads/ml-20m/movies.csv' DELIMITER ',' CSV HEADER;
ALTER TABLE movies ADD PRIMARY KEY (id);
CREATE INDEX idx_movies_title ON movies (title);

-- movies without bulk load
CREATE TABLE movies (id integer primary key, title varchar(255), genres text);
CREATE INDEX idx_movies_title ON movies (title);
COPY movies (id, title, genres) FROM '/Users/eyj/Downloads/ml-20m/movies.csv' DELIMITER ',' CSV HEADER;

-- ratings with bulk load
CREATE TABLE ratings (userId integer, movieId integer, rating real, timestamp bigint);
COPY ratings (userId, movieId, rating, timestamp) FROM '/Users/eyj/Downloads/ml-20m/ratings.csv' DELIMITER ',' CSV HEADER;

	# Time: 34848.688 ms (00:34.849)

CREATE INDEX idx_ratings_timestamp ON ratings (timestamp);

	# Time: 21425.664 ms (00:21.426)

# -- ratings without bulk load
CREATE TABLE ratings (userId integer, movieId integer, rating real, timestamp bigint);
CREATE INDEX idx_ratings_timestamp ON ratings (timestamp);
COPY ratings (userId, movieId, rating, timestamp) FROM '/Users/eyj/Downloads/ml-20m/ratings.csv' DELIMITER ',' CSV HEADER;

	# Time: 152247.172 ms (02:32.247)
