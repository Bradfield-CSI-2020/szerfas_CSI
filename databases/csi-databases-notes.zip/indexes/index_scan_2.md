```
# terminal window 1
psql test

# terminal window 2
ps aux | grep postgres
lldb
attach <pid>
b btgetbitmap
continue

# terminal window 1
EXPLAIN ANALYZE SELECT * FROM movies WHERE title > 'A' and title < 'C';

# terminal window 2
next # until heapTid has been assigned
p *heapTid

# terminal window 3
psql test
SELECT pg_relation_filepath('movies');
^D

pg_filedump -f -i -D int,varchar,text <path>
# jump to the page
# jump to the item
# confirm that the title falls in the range

# repeat the process with another heapTid
```