\timing on

-- ensure movies table is loaded
CREATE TABLE movies (id integer, title varchar(255), genres text);
COPY movies(id, title, genres) FROM '/Users/elliott/Desktop/databases/ml-20m/movies.csv' DELIMITER ',' CSV HEADER;
ALTER TABLE movies ADD PRIMARY KEY (id);
CREATE INDEX idx_movies_title ON movies (title);

-- sequential scan
EXPLAIN ANALYZE SELECT * FROM movies WHERE title > 'A';

-- index scan
EXPLAIN ANALYZE SELECT * FROM movies WHERE title > 'A' and title < 'Ab';

-- bitmap scan?!
EXPLAIN ANALYZE SELECT * FROM movies WHERE title > 'A' and title < 'C';

-- force no bitmap scan
SET enable_bitmapscan = 'off';
EXPLAIN ANALYZE SELECT * FROM movies WHERE title > 'A' and title < 'C';

-- restore bitmap scan
SET enable_bitmapscan = 'on';

-- index only scan; why does this work?
EXPLAIN ANALYZE SELECT title FROM movies WHERE title > 'A' and title < 'Ab';
