CREATE INDEX idx_movies_title_comedy ON movies (title) WHERE (genres LIKE '%Comedy%');

EXPLAIN SELECT * FROM movies WHERE title > 'A' AND genres LIKE '%Comedy%';
EXPLAIN SELECT * FROM movies WHERE title > 'A' AND title < 'Ab' AND genres LIKE '%Comedy%';
EXPLAIN SELECT * FROM movies WHERE title > 'A' AND title < 'C' AND genres LIKE '%Comedy%';
