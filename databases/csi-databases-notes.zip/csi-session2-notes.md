## Objectives

By the end of this session, you should understand:

* Architecture of a query executor
* External sorting and hashing, why it's useful

## Agenda

"block", "page", "chunk"
	8kb unit of I/O

Questions about prework?
	External sorting
		What's the high level algorithm we use?
			"conquer and then merge"

		step 1: read 4gb of data into memory
			sort in memory
			write them back out

		step 2:
			take N of them, merge them in sorted order

		step 3:
			repeat this process until you've merged evreything into a single run

	External hashing
		Split up input to be smaller hashes on disk?
			This is an intermediate step of the process

id,name,fav letter
1,alice,A
2,bob,Z
3,carol,D
4,dave,A
5,eve,D
6,fred,G
7,george,Z

SORT by fav letter:
id,name,fav letter
1,alice,A
4,dave,A
3,carol,D
5,eve,D
6,fred,G
2,bob,Z
7,george,Z

HASH by fav letter:
3,carol,D
5,eve,D
1,alice,A
4,dave,A
2,bob,Z
7,george,Z
6,fred,G

```
h := make(map[string][]row)
for _, row := range rows {
	key := row.favLetter
	h[key] = append(h[key], row)
}

result = make([]row)
for key, rows := range h {
	result = append(result, rows...)
}
return result
```

Go over solutions
(If time allows) Live code some stretch goals
Look at some query plans
Discuss external sorting / hashing algorithms
(If time allows) Inspect temp files generated during Postgres sorting

## Open questions

When (if ever) does a database do CLUSTER in the background?

What's "NVME", what are the implications?
	Damian: actual hard drives look more like sticks of RAM

How does Postgres handle hashing in the case where a single value is REALLY common, so much that it doesn't fit in memory