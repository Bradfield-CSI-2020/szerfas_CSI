## Objectives

By the end of this session, you should understand:

* The role of "transactions" in an RDBMS
* How the SQL standard defines "isolation levels"
* How Postgres uses snapshot isolation (instead of 2PL)

## Agenda

Prework omission
* https://archive.org/details/UCBerkeley_Course_Computer_Science_186/Computer+Science+186+-+2015-04-21-4nYIWjsHz7o.mkv
	* 16:10 - 35:49
	* 49:43 - 1:07:39

High level discussion of transactions:
	* So far, we've only been running single queries at a time, as one-off operations.
		* What's a "transaction"?
			* Avoid conflicts between more than one user
			* Writes might depend on previous reads / writes
				* Bank account balance
				* Increment a counter atomically
		* Why is this idea useful?
			* "Atomic operations" in a multi-user system
	* Why do we want our database system to handle concurrent transactions?
		* Why not just run transactions serially?
			* Throughput!
			* CPU part and I/O part
				* Don't want e.g. CPU doing nothing when someone else doing I/O
	* What are examples of things that can go wrong if we're not careful in how we handle concurrent transactions?
		* Data can get mangled, various versions of data races / race conditions
		* Different transactions can overwrite each other's work
	* What's "ACID"?
		* Drug that was popular in 60s / 70s (historical note)
		* Atomicity
			* Work done as one unit (all or nothing)
		* Consistency
			* Guarantees are fulfilled
				* Unique constraint
		* Isolation
			* Transaction not affected by others
			* "Serializability"
			* Illusion that you have exclusive access to the DB
		* Durability
			* Will persist information if commit / finish transaction
	* What does it mean for transactions to be "serializable"?
		* We want to make sure it happens in *some* serial order
		* Why are multiple serial orders ok (why aren't we aiming for some fixed one)?
			* Within an individual transaction, we definitely want the operations in THAT transaction to happen in the order they're given
			* Between different transactions, we can tolerate different possible orderings

	Transaction 1:
		BEGIN
		DEPOSIT 50
		END

Two possibilities:
	1, 2
	2, 1

Locking:
	* Why might we use locks in a database system?
		* Helps with transactions: lock rows, tables to ensure isolation guarantees
	* What's the difference between locks (in this database context) and "mutexes" (which you've been working with)?
		* Different types of access: in DB we're using "read/write" locks (shared access / exclusive access)
		* Database lock vs. RWMutex from Go?
			* Database lock might be re-entrant
		* DB lock implementation:
			* hashmap
				* key: entity being locked
				* value: txid that has it, queue of waiting txids

```
type lockInfo struct {
	currHolder string
	waiting []string
}

var lockTableMutex sync.Mutex
var lockTable map[string]lockInfo

func Acquire(key, tx string) {
	info := lockTable[key]
	if info.currHolder == "" {
		// Can acquire now
	} else {
		// Add yourself to waiting queue, block
	}
}
```

	* What's "two-phase locking"?
		* You have some set of things being locked
		* As soon as you let one go, you can't acquire more
			* What context are we talking about
			* In the context of one transaction

	* Why is this beneficial, to do 2 phase locking?
		* Once you release your lock, another TX could come in and make some change
		* Prevents deadlocks?
		* Ensure conflict serializability

T1: Lock A, Lock B
T2: Lock B, Lock A

Let's try to come up with one

T1 writes A before T2 writes A
T2 writes B before T1 writes B

### actual

T1: Lock A, write A, release A,                                                        Lock B, read B, release B
T2:                             Lock A, read A, release A, Lock B, write B, release B

### T1 first

T1: Lock A, write A, release A, Lock B, read B, release B
T2:                                                       Lock A, read A, release A, Lock B, write B, release B

### T2 first

T1:                                                       Lock A, write A, release A, Lock B, read B, release B
T2: Lock A, read A, release A, Lock B, write B, release B

Is this a "serializable" situation?
Is there a valid serial ordering?

	* What are "cascading aborts"?
		* Already talked about this, if one abort, transaction that depends on it needs to abort
	* What's "strict two-phase locking"? Why is it useful?
		* Release everything immediately once you start releasing
		* Avoid cascading aborts
	* What's a "deadlock"?
		* How do you deal with it?
		* Why do you need to deal with it in databases but not when implementing a system involving mutexes?
	* What sort of granularity should we lock at?
		* Depends

What are each of these isolation levels in the SQL standard, and how can we understand them in terms of what locks are held?
	* Hint: they describe phenomena which are allowed to occur

	* Read Uncommitted
		* Hypothesis: reading before things flushed to disk?
		* If one transaction has written something but it hasn't committed yet, maybe other transactions CAN read that value

T1: lock A, write A,        do other stuff, commit
T2:                  read A

T2 is just gonna do no locking
	"run T2 at isolation level read uncommitted"
	Would a transaction running at "read uncommitted" acquire locks for writing
		* Think so but need to confirm

	* Read Committed
		* You could see data from another transaction once it commits
		* When you want to read, it acquires a lock?

T1: lock A, write A,         do other stuff, commit / release locks
T2:                  lock A,                                        read A

	* Repeatable Read
		* Avoids the problems above, but you could get "write skew"

	* Serializable
		* Can guarantee equivalent to "one after another"

What are each of these problems, and how can they be prevented?
	* Dirty Read
		* Can read uncommited data
	* Nonrepeatable Read
		* Doing a read again can give you a different result (another transaction committed in the meantime)
	* Phantom Read
		* 
	* Serialization Anomaly / Write Skew

What's "snapshot isolation"?

What's the default isolation level for Postgres transactions?
	* See https://www.postgresql.org/docs/current/transaction-iso.html
	* Note: before version 9.1, if you asked for "Serializable" you'd actually get "Repeatable Read" instead!

Why don't the Postgres serialization levels exactly correspond to the SQL standard?
	* See table 13.1 in the above link
	* Why are "Read Uncommitted" and "Read Committed" the same thing in Postgres?
	* Why doesn't "Repeatable Read" suffer from Phantom Reads in Postgres?

## Examples

### Transaction IDs

BEGIN;
SELECT txid_current();

### Tuple structure review

HeapTupleHeader
	t_xmin
		transaction that inserted
	t_xmax
		transaction that deleted or updated (or 0)
	t_cid
		which operation within a given transaction
	t_ctid
		itself or a new tuple
			latest or next?

SELECT ctid, * FROM movies WHERE ctid = '(0, 1)';
	What happens if you do this for an old row?

* INSERT
* DELETE
* UPDATE (2x in one transaction)

---

---

0 transactions committed

T1 starts

T2 starts, updates record
				xmax 0, xmin = T2's txid, > T1's txid

T1 reads record A
	will see a txid > its own, will not return that value

T2 commits

T1 tries reading again

what happens

---

READ_UNCOMMITTED

	TX 1: BEGIN,        WRITE A,             COMMIT
	TX 2: BEGIN, READ A            READ A

READ_COMMITTED

	TX 1: BEGIN,        WRITE A,             COMMIT
	TX 2: BEGIN, READ A            READ A            READ A

REPEATABLE READ

	TX 1: BEGIN,        WRITE A,             COMMIT
	TX 2: BEGIN, READ A            READ A            READ A

### Transaction snapshot

SELECT txid_current_snapshot();

	xmin
		earliest txid that's still active
	xmax
		first unassigned txid
	xip_list
		active txids	

### Multiple transactions

* Nonrepeatable Read
* Phantom Read
* Serialization Anomaly / Write Skew

For each of the problems that can arise:
	* Exhibit an example
	* Try it again with both transactions on a more strict isolation level
	* Try it again, mixing and matching isolation levels?!

"dots" example from https://wiki.postgresql.org/wiki/SSI

Can we cause a transaction to abort?

## Sources

* https://www.interdb.jp/pg/pgsql05.html
* https://www.postgresql.org/docs/current/storage-page-layout.html
* https://www.postgresql.org/docs/current/mvcc.html
* https://www.postgresql.org/docs/current/biblio.html
* https://www.cs.umd.edu/class/spring2012/cmsc724/franklin97concurrency.pdf
* https://www.microsoft.com/en-us/research/wp-content/uploads/2016/02/tr-95-51.pdf
* https://web.stanford.edu/class/cs345d-01/rl/aries.pdf
* https://wiki.postgresql.org/wiki/SSI
* https://wiki.postgresql.org/wiki/Serializable
* https://arxiv.org/pdf/1208.4179.pdf
