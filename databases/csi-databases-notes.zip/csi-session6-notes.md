## Objectives

By the end of this session, you should understand:

- What can vary when choosing a good query
- Statistics used to estimate running time
- Steps involved in query optimization

In addition, you should be able to:

- Anticipate what plans will be chosen
- Interpret the output of the planner
- Identify why a particular plan was chosen

## Discussion

What are we taking into account during query planning?
	What is the "search space"?
		How we find the data from the "base tables"
			Sequential scan of entire table
			Read an index that has the fields you care about
				"Index only scan"
			Index + heap file together
				"Index scan"
			etc.
		Join algorithms
			Nested loop join
				"Cross product"
			Sort merge join
			Hash join
		How you put those two together
			What order do you do the joins?
			Dynamic programming algorithm is still used
			"Left-deep tree heuristic" from system R
				(Heuristic not used in Postgres)
		When do you do projections / selections
			Ideally as early as possible ("low" in the tree)
		Query rewriting?
			Could happen in optimizer but in Postgres happens in a previous "phase"
		Sorting / partitioning
			When do you sort / partition
			Do you even sort at all?
			Do you use an index that already has the order you want?
		"Materialize"
			Cached versions of tables

How do we actually go through the search space to find a good query plan?
	Enumerate all individual decisions
		-> get all possible query plans that will get the job done
	How do we measure cost?
		-> amount of files you have to read?
			-> in units of pages
		-> joins
	OK, now we have all possible plans and a cost for each of those
	Pick the cheapest

fib:
	0, 1 are base cases
	we don't need to do anything complicated,
	we just return 0 or 1

How does the "dynamic programming" algorithm work?

"memoization"

What is the "memo table" we're going to build

What's the key, what is the cached result for that key

	key:
		set of tables
		join conditions for those tables
		resulting ordering

	cached result:
		optimal query plan to get that result

	e.g.
		key:
			{movies, ratings, users}
			where clauses:
				WHERE ...
			conditions:
				movies.id = ratings.movieid
				ratings.userid = users.id
			ordering:
				rating desc

		cached result:
			subtree with lowest cost estimate that will
			give us the output corresponding to the key

We're gonna build up a table of results like this, and populate it with more and more complex / interesting things until we actually get the entire query we wanted

Step 1: we populate the memo cache with single table "keys"

{

	{movies}, no join conditions, ordered by movieid:
		SEQ SCAN on movies

	{movies}, no join conditions, ordered by title:
		INDEX SCAN on movies using idx_movies_title

	{ratings}, no join conditions, ordered by userid:
		INDEX SCAN on ratings using idx_ratings_userid

	...
}

	// can do this right away (when scanning movies)
	WHERE movie.id > 5

	// can't do this until your "Subtree" has both ratings and users
	WHERE ratings.rating > users.average_rating

Next step: try to build up "keys" involving TWO tables
{

	(do this for every "interesting" combination of tables we'd care about)

	{movies, ratings} join on movies.id = ratings.movieid, ordered by movieid
                sort merge join
				 /           \
				/             \
		SEQ SCAN movies   IDX SCAN ratings

	// Everything involving one table

	{movies}, no join conditions, ordered by movieid:
		SEQ SCAN on movies

	{movies}, no join conditions, ordered by title:
		INDEX SCAN on movies using idx_movies_title

	{ratings}, no join conditions, ordered by userid:
		INDEX SCAN on ratings using idx_ratings_userid

	...
}

Let's say our entire query involves 6 tables
	-> approx how many keys are gonna end up in the memo cache

{movies}
{users}
{ratings}

{movies, users}
...

"how many subsets of 6 elements are there"

each of the tables you get a bit

  0      0        0       0        0            0
movies, users, ratings, venues, critics, streamingservices

				movies is included, users is included, rest aren't
{movies, users} 110000

2^6 possibilities

not O(n!)

it's gonna be O(2^n)

how many total combinations are there?

Next step: 3 tables

	{movies, ratings, users}

		{movies}    {ratings, users}
		{users} {movies, ratings}
		{ratings} {movies, users}

Next step: 4 tables

	{movies, ratings, users, venues}

		{movies} {ratings, users, venues}
		{ratings} {movies, users, venues}
		etc.
		{movies, ratings}, {users, venues}
		{movies, users}, {ratings, venues}

SELECT * FROM movies, ratings WHERE movie.movieid = ratings.movieid

	Base case
		accessing a single table
			what's the best way to access movies
			what's the best way to access ratings

	Way of building up more complicated pieces from simpler ones

Next up:
	Easy fictional example
	Specific example

## Exercises

set a breakpoint on `cost_seqscan` and `cost_index`

	EXPLAIN SELECT * FROM movies WHERE title > 'A';

set a breakpoint on `cost_tuplesort`

	EXPLAIN SELECT * FROM movies ORDER BY genres LIMIT 5;
	EXPLAIN SELECT * FROM movies ORDER BY genres;

rest of `index_scan.sql`

`optimization-exercise-sample.sql`

	\i /Users/eyj/Dropbox/Bradfield/databases/optimization-exercise-sample.sql

### Functions / constants

costsize.c
	cost
	cost_seqscan
	cost_index
	cost_tuplesort
	clause_selectivity

planmain.c
	query_planner
		add_base_rels_to_query
		make_one_rel
			set_base_rel_pathlists
			make_rel_from_joinlist
				standard_join_search

### Data Structures

PlannerInfo
RelOptInfo

	*(Path *)(l->elements->ptr_value)

## Open Questions

Are there any special optimizations for quickly accessing the catalog for query planning purposes
