## Before

### Index File

In Block 119

```
 Item  61 -- Length:   32  Offset: 5816 (0x16b8)  Flags: NORMAL
  Block Id: 156  linp Index: 87  Size: 32
  Has Nulls: 0  Has Varwidths: 1

  16b8: 00009c00 57002040 2d517561 6c697479  ....W. @-Quality
  16c8: 20537472 65657420 28313933 37290000   Street (1937)..
```

### Heap File

In Block 156

```
 Item  87 -- Length:   71  Offset: 1568 (0x0620)  Flags: NORMAL
  XMIN: 2  XMAX: 0  CID|XVAC: 0
  Block Id: 156  linp Index: 87   Attributes: 3   Size: 24
  infomask: 0x0b02 (HASVARWIDTH|XMIN_COMMITTED|XMIN_INVALID|XMAX_INVALID) 

  0620: 0e040000 00000000 00000000 00009c00  ................
  0630: 57000300 020b1800 af3e0100 2d517561  W........>..-Qua
  0640: 6c697479 20537472 65657420 28313933  lity Street (193
  0650: 37292b43 6f6d6564 797c4472 616d617c  7)+Comedy|Drama|
  0660: 526f6d61 6e6365                      Romance         

COPY: 81583     Quality Street (1937)   Comedy|Drama|Romance
```

## After

```
UPDATE movies SET genres = 'Drama|Horror|Romance' WHERE id = 81583;
CHECKPOINT;
```

### Expectation

Heap file
	Should appear twice, one for older and one for newer

Index file
	Not sure what to expect
	Block Id changed or not?
	linp index changed or not?

### Actual

Heap file
	
**In Block 156** (800 free space)

```
Item  87 -- Length:   71  Offset: 1568 (0x0620)  Flags: NORMAL
  XMIN: 2  XMAX: 1250  CID|XVAC: 0
  Block Id: 265  linp Index: 105   Attributes: 3   Size: 24
  infomask: 0x0302 (HASVARWIDTH|XMIN_COMMITTED|XMIN_INVALID) 

  0620: 0e040000 e2040000 00000000 00000901  ................
  0630: 69000300 02031800 af3e0100 2d517561  i........>..-Qua
  0640: 6c697479 20537472 65657420 28313933  lity Street (193
  0650: 37292b43 6f6d6564 797c4472 616d617c  7)+Comedy|Drama|
  0660: 526f6d61 6e6365                      Romance         

COPY: 81583     Quality Street (1937)   Comedy|Drama|Romance
```

**In Block 265**

```
Item 105 -- Length:   71  Offset:  504 (0x01f8)  Flags: NORMAL
  XMIN: 1250  XMAX: 0  CID|XVAC: 0
  Block Id: 265  linp Index: 105   Attributes: 3   Size: 24
  infomask: 0x2802 (HASVARWIDTH|XMAX_INVALID|UPDATED) 

  01f8: e2040000 00000000 00000000 00000901  ................
  0208: 69000300 02281800 af3e0100 2d517561  i....(...>..-Qua
  0218: 6c697479 20537472 65657420 28313933  lity Street (193
  0228: 37292b44 72616d61 7c486f72 726f727c  7)+Drama|Horror|
  0238: 526f6d61 6e6365                      Romance         

COPY: 81583     Quality Street (1937)   Drama|Horror|Romance
```

(this was at the very end of the file)

Index file

```
Item  61 -- Length:   32  Offset: 5816 (0x16b8)  Flags: NORMAL
  Block Id: 156  linp Index: 87  Size: 32
  Has Nulls: 0  Has Varwidths: 1

  16b8: 00009c00 57002040 2d517561 6c697479  ....W. @-Quality
  16c8: 20537472 65657420 28313933 37290000   Street (1937)..
```

Now we vacuum

### Expectation

- Reordered heap file?
- Will the duplicate still appear for Quality Street?
	- No?
- Will the index change?
	- Depends on where the duplicate goes!

**Index File**

Points to new location in heap file

```
 Item  61 -- Length:   32  Offset: 5816 (0x16b8)  Flags: NORMAL
  Block Id: 265  linp Index: 105  Size: 32
  Has Nulls: 0  Has Varwidths: 1

  16b8: 00000901 69002040 2d517561 6c697479  ....i. @-Quality
  16c8: 20537472 65657420 28313933 37290000   Street (1937)..
```

Now we change the title

```
UPDATE movies SET title = 'Quantity Street (1937)' WHERE movieid = 81583;
```