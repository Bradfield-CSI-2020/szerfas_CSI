## Objectives

By the end of this session, you should understand:

- How to determine / control what join algorithms Postgres is using
- How each algorithm works, performance characteristics

## Agenda

- Questions?

- Quick discussion / review
	- Quick poll: anyone implement joins by hand in their work?
		- Hipmunk ORM (designed by founder)
			- "Can never make an expensive query"
			- ORM didn't allow queries that use DB join?
				- So people wrote joins by hand
			- UserData.find(userId)
				-> under the hood SQL query that's like

				```
				SELECT * FROM users WHERE id = $;
				```

			- Benefit of this approach:
				- Less load on the database!
					- Ton of app servers, but database is a bottleneck

		- Jake's company (on Mongo) does this a lot

	- Why are join algorithms useful
		- Severe performance implications in how you do it, so doing it right -> high leverage
		- Allows you to "normalize" data
			- avoid repeating data (e.g. "users" table, "books" table)
			- avoid having to update multiple places / get inconsistencies
		- Putting data in context (relationships with other data)
			- e.g. only interested in data in one table if you can filter it based on attribute from another
		- Structured / tree-like data
			- classic "employee / manager table"
			- employees (name, id, manager_id, salary)
				- manager_id is also a valid employee id
			- find all employees that make more than their manager
				SELECT * FROM employees e, employees m ON e.manager_id = m.id WHERE e.salary > m.salary;

	- Three join algorithms
		- nested loop
			- loop each record in one table
				- loop each record in other table
					- perform check (does it satisfy join condition)

		- index nested loop
			- loop each record in one table
				- use index to pull out all matching rows from other table

		- question:
			- how could nested loop POSSIBLY be better than
			- index nested loop?!?!

		- let's start by getting a better version of nested loop
			- 

		- sort merge
			- sort both inputs according to same criteria
			- walk the "heads" down (one for each of the inputs)
			- measure in # of IOs
				- 1 IO on A and B to read it in
				- 1 IO to write it out once it's sorted
				- third IO to read it in (for merging)
				- fourth IO (might have it for just a subset of the records)
				- 3 * (# pages in A + # of pages in B) + # of output pages?

		- hash
			- 

	- How did implementations go?

- Explore queries in Postgres
- If time allows:
	- Discuss some of the optional extra content from the "Indexes" session
	- Inspect buffer manager stats
	- Look for on-disk data in the middle of a query

## Queries to Explore

	-- Cartesian product
	-- movies has R rows
	select * from movies as m, movies as n;

	-- Ratings for Toy Story
	select * from ratings as r, movies as m
	where r.movieid = m.movieid and m.title = 'Toy Story (1995)';

	-- Ratings for all movies, not just Toy Story
	select m.title, r.rating
	from movies as m, ratings as r
	where m.movieid = r.movieid;

	-- Top rated movies
	select r.movieid, avg(r.rating) as avg_rating
	from movies as m, ratings as r
	where m.movieid = r.movieid
	group by r.movieid
	order by avg_rating desc
	limit 10;

	-- Remove the order
	select r.movieid, avg(r.rating) as avg_rating
	from movies as m, ratings as r
	where m.movieid = r.movieid
	group by r.movieid
	limit 10;

## Useful Commands

	-- turn off hash join
	set enable_hashjoin=off;

	-- other settings
	-- see https://www.postgresql.org/docs/current/runtime-config-query.html

	enable_mergejoin
	enable_nestloop

	-- create indexes
	CREATE INDEX idx_movies_title ON movies (title);
	CREATE INDEX idx_movies_title ON movies using hash (title);

	-- update stats about db
	analyze;

	-- page size
	SELECT current_setting('block_size');

	-- Turn off parallel queries
	SHOW max_parallel_workers_per_gather; -- default value is 2
	SET max_parallel_workers_per_gather = 0;

	-- Other settings
