## Objectives

By the end of this session, you should understand:

* The difficulties involved in actually ensuring "atomicity" and "durability"
* How the WAL works in Postgres

## Agenda

* Discussion
	* What exactly are we trying to achieve / what are the requirements?
		* Durability: when we say something is written, it needs to actually be written (we at least need some way to recover it)
			* When a transaction commits
		* Atomicity
			* Transaction will either happen or not
			* No "only some of it happens"
			* If we are interrupted, we should lean on the "or not" side
				* Should make illusion that transaction never started

	* How could we design a simple (possibly slow) system for ensuring atomicity and durability?
		* Idea 1:
			* Keep all changes in memory until you go to commit
			* Write everything to disk before you say "yes we did commit"
		* Idea 2:
			* Keep the state of the transaction in the document
			* The record you're inserting should have a flag (valid or not)
			* Separate page for confirmation (which records are confirmed or not)
				* Your 1 page area needs some way to indicate whether all these writes are valid or not

Let's assume for today that writing a single page is atomic
	* And if it happened not to be atomic, we can at least detect it (e.g. using checksums)

Assumptions:
	* Possible to update confirmation page atomically
	* Maybe allow multiple pages, but have to be able to fit all updates for one transaction in a single page

CONFIRMATION PAGE

	{ record 1: valid at 2
	  record 2: valid
	  record 4: valid
	  ...
	}

DATA PAGE 1

	{ record 1 timestamp 1: ...
	  record 3 timestamp 5: ...
	  ...
	  record 5 timestamp 3: ...
	}

DATA PAGE 2

	{ record 1 timestamp 2: ...
	  record 2 timestamp 9: ...
	  ...
	}

How do we account for updating a record?
We'll have to do an additional check on every read
	Can likely hold confirmation pages in memory
	Can vacuum records at old timestamps in the future
What's the write performance of this approach?
	Write to (at least) 2 different pages in order to commit
	How much data are we writing?
		Every time we write we're writing an entire page

		* What would happen without some sort of WAL?
	* What's a "write-ahead log" and how does it work?
		* When we make a change, write a description of the diff to the write ahead log first
		* When we commit, flush to disk before saying "yes we did indeed commit"
		* What if the system crashes before we flushed buffer pages (containing updated records) to disk?
			* Read entries in the write ahead log, repeat history

	* Why might a WAL provide a performance benefit compared to other approaches?
		* Very expensive to write information to disk
		* Data pages vs. commit log?
			Log is append only, don't have to go all over the disk looking for empty spaces, 

	* What's Hellerstein talking about with "STEAL / NO STEAL" and "FORCE / NO FORCE"?
		* "STEAL": uncommitted data is allowed to make it to disk
			* UNDO logging
		* "NO STEAL": can't write buffer pages with uncommitted data to disk
		* "FORCE": always be writing data pages to disk on commit

* Postgres exploration
	* Inventory of relevant omponents
		* LSN: Log Sequence Number
			* ID of a log entry
			* Also tells you where to find it
				* Offsets into WAL files as well
			* Important to be monotonically increasing
				* They had better not move backwards
		* heap files (especially LSN field in page headers)
			* LSN of the most recent log record to update in this block
			* BLOCK 0: logid      0 recoff 0xdb66be38
			* BLOCK 1: logid      0 recoff 0xdb66de78 
			* Why is it useful to store per-page LSN?
				* When we are doing REDO / rewriting history:
				* When we're reapplying parts of the log to "recreate the buffer pool":
					* Each page on disk has LSN
					* Each entry in the WAL has LSN
				* Looking at a WAL entry, and it refers to page 0
					* WAL entry has LSN 1001
					* Page has LSN 500
					* We SHOULD apply that entry to the page
		* pg_wal
			* Fun fact: pg_xlog renamed to pg_wal 
				* https://github.com/postgres/postgres/commit/f82ec32ac30ae7e3ec7c84067192535b2ff8ec0e
			* format
				* "Fig. 9.8" section in https://www.interdb.jp/pg/pgsql09.html
				* Different kinds of log records: backup block, insert, checkpoint, etc.
				* "Resource Manager"
			* pg_waldump
		* pg_control
			* pg_controldata <dir>

Aside: LevelDB
* symbolic links
	ln -s <src> <dst> makes an "alias"
		pointer to another filename

* hard links
	(name, inode)
	What is the consequence of "creating a hard link?"
	ln command without -s flag

	* Slides
		* Insert operation with WAL: https://www.slideshare.net/suzuki_hironobu/fig-902
		* Recovery: https://www.slideshare.net/suzuki_hironobu/fig-903

	* Try some experiments involving:
		* Run some transactions
			* COMMIT and ABORT
		* CHECKPOINT command
		* kill -9
		* While inspecting:
			* pg_filedump output (especially lsns)
			* pg_waldump -f
			* pg_controldata

Get filename (to use as arg to pg_waldump) like this:

```
SELECT pg_current_wal_lsn();
SELECT pg_walfile_name('...');
```

The directory is (pg data directory)/pg_wal

## Resources

* Relevant Postgres docs
	* https://www.postgresql.org/docs/current/wal.html
	* https://www.postgresql.org/docs/current/runtime-config-wal.html

* Useful CLI tools
	* https://www.postgresql.org/docs/current/app-pgcontroldata.html
	* https://www.postgresql.org/docs/current/pgwaldump.html
	* https://www.postgresql.org/docs/current/pgtestfsync.html

* Check if your disk is lying to you about data being actually written
	* https://brad.livejournal.com/2116715.html

* Third-party resources on WALs
	* https://www.interdb.jp/pg/pgsql09.html
	* https://www.slideshare.net/EnterpriseDB/postgres-vision-2018-wal-everything-you-want-to-know

---

Brainstorm how to take a snapshot / backup

data on disk

1) write down current LSN (start)
2) run "checkpoint"
3) initiate the copy (you might get some old pages, some new pages)
4) copy finishes
5) get the current LSN again (end)
6) walk the log from end to start
	* apply all entries
	* skip entry if it's already been applied
	* design entries in a way where you can tell if it needs to be applied
