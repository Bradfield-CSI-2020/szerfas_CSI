- B+ tree details in postgres
	- file format

		- how would you design this yourself (high level ideas)?
			- take inspiration from existing implementation (very viable)
			- what are you trying to do
			- what we need to do
				- store a node together
					- each node is a page?
						- header
						- index item ids
						- instead of tuples, we have actual node data
							- which node it points to
				- pointers tell us where other nodes are stored
					- should all be same size
				- value that we're looking up
					- if we're indexing on int, values will all be same size
					- what if we're indexing on string / varchar
						- maybe use max size for each item in the index?
				- address of item (page, item)
			- what are some of the problems
				- function well if someone is inserting a lot of data
				- making sure tree stays balanced
					- design of the B-tree itself handles this


		- meta-data page, see `BTMetaPageData`
			- mostly blank
			- magic number to indicate "this is an index file"
			- location of root
			- level of root
		- see `nbtree.h`
		- index pages
			- same header format as heap files
				- see `PageHeaderData` in `bufpage.h`
				- # of items
				- offsets / free space
				- pointers at front, data at back
			- `BTPageOpaqueData` at the end
				- left / right siblings
				- level of node (0 for leafs)
				- flags (what kind of page is it)
	- how deep is the tree?
	- what's the branching factor for our dataset?
		- root?
		- internal nodes?
	- how full are the pages at each level?
	- what data is stored for each item?
		- how does it refer to heap file data?
	- let's do a few lookups "by hand"
	- let's try some inserts / deletes and see what happens on disk
		- INSERT INTO movies (id, title, genres) VALUES (...);
		- UPDATE movies SET title = '...' WHERE id = '...';
			- Bonus question: what happens for an index-only scan?
		- DELETE FROM movies WHERE id = ...;

- Different ways to use an index (or not)
	- What are all of these approaches?
		- Sequential Scan
		- Bitmap Scan
		- Index Scan
		- Index Only Scan
	- demo at `index_scan.sql`
	- demo at `index_scan_2.md`

- Bulk loading
	- What are the steps involved?
	- What's "fillfactor" / when do you start a new page?
		- see nbtsort.c
	- Why is bulk loading more efficient than the alternative?
	- What are the implications if you want to insert a lot of data on a table that has an index?
	- demo at `bulk_load.sql`

- Clustered indexes
	- What does it mean for an index to be "clustered"?
	- What's the difference between:
		- Having a "clustered index"
		- Storing row data directly in the index
	- How many indexes can you cluster a table on?
	- demo at `cluster.sql`

- Composite indexes
	- What's a "composite index", and why is it useful?
	- demo at `composite.sql`

- Partial indexes
	- What's a "partial index", and why is it useful?
	- demo at `partial.sql`
	- See https://heap.io/blog/engineering/speeding-up-postgresql-queries-with-partial-indexes for more details

Open Question
- If we vacuum, will the root move to block 1
- How wide is the int used to store the page for a child node?
	Elliott's guess is 32 bits but we'll see
- Does the B-tree lookup do a binary search